NUTRONUTS WEBSITE

Open index.html in a modern browser to preview the website.
Keep the assets folder beside index.html when uploading/hosting the site.

WhatsApp destination configured throughout: +91 95743 50475
Single product: NutroNuts Signature Mix — 30g — ₹30

To publish: upload the complete nutroNuts-website folder (or ZIP contents) to your hosting provider's public web directory. No payment gateway or backend is required; order and bulk enquiry forms open WhatsApp with prefilled messages.

Note: The supplied four food photographs are used as editorial ingredient/lifestyle imagery, not represented as actual product packaging. The supplied logo image is used unchanged.
